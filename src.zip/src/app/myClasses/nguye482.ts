export class Nguye482 
{
    sid!: number;
    sname!: string;
    slogin!: string;
    scampus!: string;
    stitle!: string;
}